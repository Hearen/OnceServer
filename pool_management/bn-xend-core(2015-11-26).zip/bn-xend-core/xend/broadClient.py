import broadcast

client = broadcast.BroadCastClient()
client.send("Hello")

